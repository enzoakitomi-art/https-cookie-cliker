const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Plugins.Mouse,
		C3.Plugins.Text,
		C3.Plugins.Button,
		C3.Plugins.LocalStorage,
		C3.Plugins.System.Cnds.IsGroupActive,
		C3.Plugins.Mouse.Cnds.OnObjectClicked,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.Sprite.Acts.Spawn,
		C3.Plugins.System.Acts.Wait,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.Button.Cnds.OnClicked,
		C3.Plugins.LocalStorage.Acts.SetItem,
		C3.Plugins.System.Cnds.OnLayoutStart,
		C3.Plugins.System.Acts.LoadStateJSON,
		C3.Plugins.Button.Acts.Destroy,
		C3.Plugins.System.Acts.GoToLayout
	];
};
self.C3_JsPropNameTable = [
	{CookieButton: 0},
	{Mouse: 0},
	{clicado: 0},
	{TextScore: 0},
	{ShopButton: 0},
	{mrClokkie: 0},
	{sairLOJA: 0},
	{TextScore_Loja: 0},
	{aviso_cookie: 0},
	{Sprite: 0},
	{ArmazenamentoLocal: 0},
	{salvar: 0},
	{"100Inicial": 0},
	{ChocoCoins: 0},
	{multiplicador: 0},
	{Upgrade1Comprado: 0}
];

self.InstanceType = {
	CookieButton: class extends self.ISpriteInstance {},
	Mouse: class extends self.IInstance {},
	clicado: class extends self.ISpriteInstance {},
	TextScore: class extends self.ITextInstance {},
	ShopButton: class extends self.IButtonInstance {},
	mrClokkie: class extends self.ISpriteInstance {},
	sairLOJA: class extends self.IButtonInstance {},
	TextScore_Loja: class extends self.ITextInstance {},
	aviso_cookie: class extends self.ITextInstance {},
	Sprite: class extends self.ISpriteInstance {},
	ArmazenamentoLocal: class extends self.IInstance {},
	salvar: class extends self.IButtonInstance {},
	_100Inicial: class extends self.IButtonInstance {}
}